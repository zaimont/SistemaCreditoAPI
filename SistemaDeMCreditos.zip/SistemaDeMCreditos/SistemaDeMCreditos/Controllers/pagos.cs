﻿using Microsoft.AspNetCore.Mvc;
using SistemaDeMCreditos.Modelos;
using Microsoft.EntityFrameworkCore.Storage;


namespace SistemaDeMCreditos.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class pagos : Controller
    {
        private ModelContext db;

        public pagos(ModelContext database)
        {
            this.db = database;
        }

        [HttpGet]
        public ActionResult<IEnumerable<pagosModel>> Get()
        {
            return Ok(db.pagos.ToList());
        }

        [HttpPost]
        public ActionResult Post([FromBody] pagosModel json)
        {
            if (!ModelState.IsValid)

                return BadRequest("informacion invalida");
            db.pagos.Add(json);
            db.SaveChanges();
            return Ok();

        }

        [HttpGet("{id}")]
        public async Task<ActionResult> Find(int? id)
        {
            if (id == null)
            {
                return BadRequest("no existe");
            }
            try
            {
                var item = await db.pagos.FindAsync(id);
                if (item == null)
                {
                    return NotFound();
                }
                return Ok(item);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex);
            }

        }
        [HttpPut]
        public ActionResult Put([FromBody] pagosModel json)
        {
            if (!ModelState.IsValid)
                return BadRequest("informacion invalida");
            var dbjson = db.pagos.Where(a => a.id_pagos == json.id_pagos).FirstOrDefault();
            if (dbjson == null)
            {
                return BadRequest($"pagos con id json.id no fue enncontrado");
            }
            db.Entry(dbjson).CurrentValues.SetValues(json);
            db.Update(dbjson);
            db.SaveChanges();
            return Ok();
        }
        [HttpDelete]
        [Route("{id}")]
        public ActionResult Delete(int? id)
        {
            if (!ModelState.IsValid)
                return BadRequest("informacion invalida");
            var dbjson = db.pagos.Where(a => a.id_pagos == id).FirstOrDefault();
            if (dbjson == null)
                return BadRequest($"pagos con id no encontrado");
            db.Remove(dbjson);
            db.SaveChanges();
            return Ok();
        }
    }
}
