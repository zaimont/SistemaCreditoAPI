﻿using Microsoft.AspNetCore.Mvc;
using SistemaDeMCreditos.Modelos;
using Microsoft.EntityFrameworkCore.Storage;

namespace SistemaDeMCreditos.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class cliente : Controller

    {
        private ModelContext db;

        public cliente(ModelContext database) 
        { 
        this.db = database;
        }

        [HttpGet]
        public ActionResult<IEnumerable<clienteModel>> Get()
        {
            return Ok(db.cliente.ToList());
        }

        [HttpPost]
        public ActionResult Post([FromBody] clienteModel json) 
        {
            if(!ModelState.IsValid) 
            
                return BadRequest("informacion invalida");
                db.cliente.Add(json);
                db.SaveChanges();
                return Ok();
            
        }

        [HttpGet("{id}")]
        public async Task<ActionResult> Find(int? id)
        {
            if(id == null)
            {
                return BadRequest("no existe");
            }
            try
            {
                var item = await db.cliente.FindAsync(id);
                if(item == null)
                {
                    return NotFound();
                }
                return Ok(item);
            }
            catch(Exception ex)
            {
                return StatusCode(500, ex);
            }

        }
        [HttpPut]
        public ActionResult Put([FromBody] clienteModel json)
        {
            if (!ModelState.IsValid)
                return BadRequest("informacion invalida");
            var dbjson = db.cliente.Where(a => a.id == json.id).FirstOrDefault();
            if (dbjson == null)
            {
                return BadRequest($"cliente con id json.id no fue enncontrado");
            }
            db.Entry(dbjson).CurrentValues.SetValues(json);
            db.Update(dbjson);
            db.SaveChanges();
            return Ok();
        }
        [HttpDelete]
        [Route("{id}")]
        public ActionResult Delete(int? id) 
        {
            if (!ModelState.IsValid)
                return BadRequest("informacion invalida");
            var dbjson = db.cliente.Where(a => a.id == id).FirstOrDefault();
            if (dbjson == null)
                return BadRequest($"cliente con id no encontrado");
            db.Remove(dbjson);
            db.SaveChanges();
            return Ok();
        }

    }
}
