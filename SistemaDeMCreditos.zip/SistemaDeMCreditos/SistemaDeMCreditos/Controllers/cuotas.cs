﻿using Microsoft.AspNetCore.Mvc;
using SistemaDeMCreditos.Modelos;
using Microsoft.EntityFrameworkCore.Storage;


namespace SistemaDeMCreditos.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class cuotas : Controller 
    {
        private ModelContext db;

        public cuotas(ModelContext database)
        {
            this.db = database;
        }

        [HttpGet]
        public ActionResult<IEnumerable<cuotasModel>> Get()
        {
            return Ok(db.cuotas.ToList());
        }

        [HttpPost]
        public ActionResult Post([FromBody] cuotasModel json)
        {
            if (!ModelState.IsValid)

                return BadRequest("informacion invalida");
            db.cuotas.Add(json);
            db.SaveChanges();
            return Ok();

        }

        [HttpGet("{id}")]
        public async Task<ActionResult> Find(int? id)
        {
            if (id == null)
            {
                return BadRequest("no existe");
            }
            try
            {
                var item = await db.cuotas.FindAsync(id);
                if (item == null)
                {
                    return NotFound();
                }
                return Ok(item);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex);
            }

        }
        [HttpPut]
        public ActionResult Put([FromBody] cuotasModel json)
        {
            if (!ModelState.IsValid)
                return BadRequest("informacion invalida");
            var dbjson = db.cuotas.Where(a => a.id_cuotas == json.id_cuotas).FirstOrDefault();
            if (dbjson == null)
            {
                return BadRequest($"cuotas con id json.id no fue enncontrado");
            }
            db.Entry(dbjson).CurrentValues.SetValues(json);
            db.Update(dbjson);
            db.SaveChanges();
            return Ok();
        }
        [HttpDelete]
        [Route("{id}")]
        public ActionResult Delete(int? id)
        {
            if (!ModelState.IsValid)
                return BadRequest("informacion invalida");
            var dbjson = db.cuotas.Where(a => a.id_cuotas == id).FirstOrDefault();
            if (dbjson == null)
                return BadRequest($"cuotas con id no encontrado");
            db.Remove(dbjson);
            db.SaveChanges();
            return Ok();
        }
    }
}
