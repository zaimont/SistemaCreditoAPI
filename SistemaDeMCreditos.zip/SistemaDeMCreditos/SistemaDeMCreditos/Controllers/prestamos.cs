﻿using Microsoft.AspNetCore.Mvc;
using SistemaDeMCreditos.Modelos;
using Microsoft.EntityFrameworkCore.Storage;


namespace SistemaDeMCreditos.Controllers

{
    [ApiController]
    [Route("api/[controller]")]
    public class prestamos : Controller
    {
        private ModelContext db;

        public prestamos(ModelContext database)
        {
            this.db = database;
        }

        [HttpGet]
        public ActionResult<IEnumerable<prestamosModel>> Get()
        {
            return Ok(db.prestamos.ToList());
        }

        [HttpPost]
        public ActionResult Post([FromBody] prestamosModel json)
        {
            if (!ModelState.IsValid)

                return BadRequest("informacion invalida");
            db.prestamos.Add(json);
            db.SaveChanges();
            return Ok();

        }

        [HttpGet("{id}")]
        public async Task<ActionResult> Find(int? id)
        {
            if (id == null)
            {
                return BadRequest("no existe");
            }
            try
            {
                var item = await db.prestamos.FindAsync(id);
                if (item == null)
                {
                    return NotFound();
                }
                return Ok(item);
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex);
            }

        }
        [HttpPut]
        public ActionResult Put([FromBody] prestamosModel json)
        {
            if (!ModelState.IsValid)
                return BadRequest("informacion invalida");
            var dbjson = db.prestamos.Where(a => a.id == json.id).FirstOrDefault();
            if (dbjson == null)
            {
                return BadRequest($"prestamos con id json.id no fue enncontrado");
            }
            db.Entry(dbjson).CurrentValues.SetValues(json);
            db.Update(dbjson);
            db.SaveChanges();
            return Ok();
        }
        [HttpDelete]
        [Route("{id}")]
        public ActionResult Delete(int? id)
        {
            if (!ModelState.IsValid)
                return BadRequest("informacion invalida");
            var dbjson = db.prestamos.Where(a => a.id == id).FirstOrDefault();
            if (dbjson == null)
                return BadRequest($"prestamos con id no encontrado");
            db.Remove(dbjson);
            db.SaveChanges();
            return Ok();
        }
    }
}
