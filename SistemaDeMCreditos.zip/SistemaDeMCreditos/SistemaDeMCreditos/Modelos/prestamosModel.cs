﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


namespace SistemaDeMCreditos.Modelos
{
    [Table("prestamos")]
    public class prestamosModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("id_prestamos")]
        public int id_prestamos { get; set; }

        [Column("id_cliente")]
        public int id { get; set; }

        [Column("cantidadPrestada")]
        public decimal cantidadPrestada { get; set; }

        [Column("intereses")]
        public int intereses { get; set; }

        [Column("fechaSolicitud")]
        public DateTime fechaSolicitud { get; set; }

        [Column("fechaPrestamo")]
        public DateTime fechaPrestamo { get; set; }

        [Column("estadoPrestamo")]
        public string estadoPrestamo { get; set; }

        [Column("mesesPrestamo")]
        public int mesesPrestamo { get; set; }
    }
}
