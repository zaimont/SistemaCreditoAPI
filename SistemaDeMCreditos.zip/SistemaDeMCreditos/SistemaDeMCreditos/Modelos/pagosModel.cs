﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SistemaDeMCreditos.Modelos
{
    [Table("pagos")]
    public class pagosModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        [Column("id_pagos")]
        public int id_pagos { get; set; }

        [Column("id_prestamos")]
        public int id_prestamos { get; set; }

        [Column("monto")]
        public decimal monto { get; set; }

        [Column("fechaPago")]
        public DateTime fechaPago { get; set; }

        [Column("estadoPago")]
        public DateTime estadoPago { get; set; }
    }
}
