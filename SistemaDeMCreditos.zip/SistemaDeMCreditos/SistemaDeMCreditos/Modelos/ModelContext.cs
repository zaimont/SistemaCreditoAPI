﻿using Microsoft.EntityFrameworkCore;

namespace SistemaDeMCreditos.Modelos
{
    public class ModelContext : DbContext
    {
        public ModelContext(DbContextOptions<ModelContext>options):base(options) { }
        public DbSet<clienteModel> cliente { get; set; }

        public DbSet<prestamosModel> prestamos { get; set;}

        public DbSet<pagosModel> pagos { get; set; }    

        public DbSet<cuotasModel> cuotas { get; set; }
    }
}
