﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


namespace SistemaDeMCreditos.Modelos
{
    [Table("cuotas")]
    public class cuotasModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]

        [Column("id_cuotas")]
        public int id_cuotas { get; set; }

        [Column("id_prestamos")]
        public int id_prestamos { get; set; }

        [Column("numeroCuota")]
        public int numeroCuota { get; set; }

        [Column("montoCuota")]
        public decimal montoCuota { get; set; }

        [Column("fechaVencimientoCuota")]
        public DateTime fechaVencimientoCuota { get; set; }

        [Column("estadoCuota")]
        public string estadoCuota { get; set; }
    }
}
