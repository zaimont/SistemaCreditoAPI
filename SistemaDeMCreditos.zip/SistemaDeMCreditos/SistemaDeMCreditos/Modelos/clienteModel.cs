﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


namespace SistemaDeMCreditos.Modelos
{
    [Table("cliente")]
    public class clienteModel
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column("id_cliente")]
        public int id { get; set; }

        [Column("nombre")]
        public string name { get; set; }

        [Column("ApellidoP")]
        public string apellido { get; set; }

        [Column("ApellidoM")]
        public string apellido2 { get; set; }

        [Column("telefono")] 
        public string telefono { get; set; }

        [Column("email")]
        public string email { get; set; }

        [Column("fechaN")]
        public DateTime FechaN { get; set; }

        [Column("referencias")]
        public string referencias { get;set; }

        [Column("estadoCrediticio")]
        public string estadoCrediticio { get;set; }


    }
}
